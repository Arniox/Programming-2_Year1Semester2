package filmDataBaseApp;

import javax.swing.JPanel;

public class FilmDataBaseView extends JPanel{

	
	
}
